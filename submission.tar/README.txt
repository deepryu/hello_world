// README.txt 
Student ID: z5128960
Name: Xijia Xin

start the server/server.py then using the pydocument in client to test function


To connect using the mongo shell:
mongo ds163705.mlab.com:63705/lab07db -u admin -p admin

